const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/Auth');
const { isAdmin } = require('../middleware/isAdmin');
router.post('/user', [auth, isAdmin], async (req, res) => {
  const { email, password, name, role } = req.body;

  try {
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ message: 'User already exists' });
    }

    user = new User({ email, password, name, role });
    await user.save();

    res.status(201).json(user);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});
router.get('/user', [auth, isAdmin], async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});
router.put('/user/:id', [auth, isAdmin], async (req, res) => {
  const { email, password, name, role } = req.body;

  try {
    let user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (email) user.email = email;
    if (password) {
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password, salt);
    }
    if (name) user.name = name;
    if (role) user.role = role;

    user = await user.save();
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});
router.delete('/user/:id', [auth, isAdmin], async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    await user.remove();
    res.json({ message: 'User removed' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});
router.post('/admin', [auth, isAdmin], async (req, res) => {
  const { email, password, name } = req.body;

  try {
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ message: 'Admin already exists' });
    }

    user = new User({ email, password, name, role: 'admin' });
    await user.save();

    res.status(201).json(user);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});
router.put('/admin/:id', [auth, isAdmin], async (req, res) => {
  const { email, password, name } = req.body;

  try {
    let user = await User.findById(req.params.id);
    if (!user || user.role !== 'admin') return res.status(404).json({ message: 'Admin not found' });

    if (email) user.email = email;
    if (password) {
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password, salt);
    }
    if (name) user.name = name;

    user = await user.save();
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});
router.delete('/admin/:id', [auth, isAdmin], async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user || user.role !== 'admin') return res.status(404).json({ message: 'Admin not found' });

    await user.remove();
    res.json({ message: 'Admin removed' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;

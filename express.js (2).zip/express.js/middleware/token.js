const fs = require('fs');

const saveRefreshToken = (token) => {
  fs.writeFileSync('./refreshTokens.txt', token, { flag: 'a' });
};

const getRefreshTokens = () => {
  if (!fs.existsSync('./refreshTokens.txt')) {
    return [];
  }
  const tokens = fs.readFileSync('./refreshTokens.txt', 'utf-8').split('\n').filter(Boolean);
  return tokens;
};

const removeRefreshToken = (token) => {
  const tokens = getRefreshTokens();
  const newTokens = tokens.filter(t => t !== token);
  fs.writeFileSync('./refreshTokens.txt', newTokens.join('\n'));
};

module.exports = { saveRefreshToken, getRefreshTokens, removeRefreshToken };
